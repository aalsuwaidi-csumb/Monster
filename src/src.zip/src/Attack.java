public interface Attack  extends Ability{

    public Integer attack(Monster monster);

}
